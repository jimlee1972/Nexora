import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
source = work/'frozen-source'
source.mkdir(exist_ok=False)
paths = [line for line in subprocess.check_output(['git','diff','--name-only','origin/main'],
          cwd=root,text=True).splitlines() if line.startswith(('Tools/TwoD/','Tests/TwoD/'))]
paths += ['Engine/TwoD/src/Queries.cpp','Engine/TwoD/src/Scene.cpp','Engine/TwoD/src/GameplayUi.cpp',
          'Engine/TwoD/src/Assets.cpp','Engine/TwoD/src/Lifecycle.cpp',
          'Engine/TwoD/include/Nexora/TwoD/Queries.h','Engine/TwoD/include/Nexora/TwoD/Scene.h',
          'Engine/TwoD/include/Nexora/TwoD/GameplayUi.h','Engine/TwoD/include/Nexora/TwoD/Assets.h',
          'Engine/TwoD/include/Nexora/TwoD/Lifecycle.h','Engine/Presentation/src/Dx12Surface.cpp',
          'Engine/Presentation/src/VulkanSurface.cpp','Engine/Presentation/src/RenderSurface.cpp',
          'Engine/Presentation/include/Nexora/Presentation/RenderSurface.h',
          'Engine/Presentation/include/Nexora/Presentation/Surface.h',
          'Engine/Core/src/Memory.cpp','Engine/Core/src/ProcessMemory.cpp',
          'Engine/Core/include/Nexora/Core/Memory.h','Engine/Core/include/Nexora/Core/ProcessMemory.h']
metadata = dict(base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=root,text=True).strip(),
                candidate_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
                scope='Measured working source is base plus implementation.patch and exact byte source snapshots.',
                files={})
def sha(data):
    return hashlib.sha256(data).hexdigest()
for relative in sorted(set(paths)):
    data = (root/relative).read_bytes()
    target = source/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    metadata['files'][relative] = dict(sha256=sha(data),lf_sha256=sha(data.replace(b'\r\n',b'\n')),
                                     size=len(data))
patch = subprocess.check_output(['git','diff','--binary','origin/main','--','Tools/TwoD','Tests/TwoD'],cwd=root)
(work/'implementation.patch').write_bytes(patch)
metadata['patch_sha256'] = sha(patch)
old = subprocess.check_output(['git','show','origin/main:Tools/TwoD/Benchmark.cpp'],cwd=root).decode()
new = (root/'Tools/TwoD/Benchmark.cpp').read_text(encoding='utf-8')
def body(text):
    text = text.replace('\r\n','\n')
    return text[text.index('void Measure('):text.index('} // namespace\nint main')].encode()
assert body(old) == body(new), 'Original Measure workload changed'
metadata['original_measure_body_sha256'] = sha(body(new))
exe = root/'build/windows-showcase-shipping/bin/Shipping/NexoraTwoDBenchmark.exe'
target = work/'candidate-benchmark.exe'
assert not target.exists()
shutil.copy2(exe,target)
metadata['executable_sha256'] = sha(target.read_bytes())
(work/'source-manifest.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print('Frozen',len(metadata['files']),'source files; original Measure identical; EXE',metadata['executable_sha256'])
