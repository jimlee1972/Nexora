import csv
import json
from pathlib import Path

work = Path(__file__).resolve().parent
formal = work/'formal'
stages = ['reload_ms','begin_frame_ms','populate_ms','index_ms','query_ms','extract_ms',
          'ui_ms','draw_ms','end_frame_ms']
output = {}
for stem in ['dx12-soak','vulkan-soak']:
    worst = []
    over = []
    counts = dict(over_33ms=0,over_66ms=0)
    samples = []
    for row in csv.DictReader((formal/f'{stem}-frames.csv').open(encoding='utf-8')):
        if row['warmup'] == '1':
            continue
        value = float(row['cycle_ms'])
        counts['over_33ms'] += value > 1000/30
        counts['over_66ms'] += value > 2000/30
        if value > 2000/30:
            over.append(row)
        if stem == 'vulkan-soak' and 24413 <= int(row['frame']) <= 24418:
            samples.append(row)
    output[stem] = dict(counts=counts,over_max=over,submission_neighborhood=samples)
original = list(csv.DictReader((formal/'dx12-original-1-frames.csv').open(encoding='utf-8')))
case = [r for r in original if r['objects']=='10000' and r['sparse']=='0' and
        r['overlap']=='0' and r['warmup']=='0']
output['dx12-original-1-mixed10000'] = dict(
    over_p99_budget=sum(float(r['frame_ms'])>1000/30 for r in case),
    worst=sorted(case,key=lambda r:float(r['frame_ms']),reverse=True)[:10])
# Verify original-load output metrics against the preceding frozen screen.
fields = ['objects','sparse','overlap','native','frames','warmup_frames','gpu_samples','visible',
          'culled','sprite_batches','covered_aabb_ratio','query_hits','vendor_id','device_id',
          'driver_version','driver_version_format','backend_requested']
baseline = work.parents[1]/'Engine/TwoD/evidence/Windows-M6-DX12Pacing-2026-10-18'
equivalence=[]
for backend in ['dx12','vulkan']:
    for repeat in [1,2]:
        old=list(csv.DictReader((baseline/f'{backend}-{repeat}.csv').open(encoding='utf-8')))
        new=list(csv.DictReader((formal/f'{backend}-original-{repeat}.csv').open(encoding='utf-8')))
        mismatches=[dict(case=i,field=k,old=a[k],new=b[k])
                    for i,(a,b) in enumerate(zip(old,new)) for k in fields if a[k]!=b[k]]
        equivalence.append(dict(backend=backend,repeat=repeat,rows=len(new),mismatches=mismatches))
assert all(e['rows']==6 and not e['mismatches'] for e in equivalence)
output['original_load_equivalence']=equivalence
(work/'diagnostics.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v.get('counts',v.get('over_p99_budget')) for k,v in output.items()
                  if isinstance(v,dict)},indent=2))
