import importlib.util
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('gate', root/'Tools/TwoD/RunIntegratedAcceptance.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
results = []
for backend in ['dx12', 'vulkan']:
    stem = work / f'duration-{backend}'
    args = [str(root/'build/windows-showcase-shipping/bin/Shipping/NexoraTwoDBenchmark.exe'),
            '--native', '--backend', backend, '--integrated', '--frames', '4',
            '--soak-seconds', '1', '--report', str(stem.with_suffix('.csv')),
            '--frame-trace', str(stem.with_name(stem.name+'-frames.csv'))]
    if not stem.with_suffix('.csv').exists():
        with stem.with_suffix('.stdout').open('wb') as out, stem.with_suffix('.stderr').open('wb') as err:
            subprocess.run(args, stdout=out, stderr=err, check=True, timeout=120)
    result = gate.integrated_result(stem.with_suffix('.csv'),
                                   stem.with_name(stem.name+'-frames.csv'), 1, 600)
    results.append(dict(backend=backend, **result))
    print(backend, result['summary']['measured_seconds'], result['correctness_errors'], flush=True)
    assert result['correctness_pass'], result['correctness_errors']
    assert result['resource_pass']
(work/'duration-smoke.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf-8')
print('Duration/warm-up/streaming/resource gate smoke passed; not a long-soak verdict.', flush=True)
