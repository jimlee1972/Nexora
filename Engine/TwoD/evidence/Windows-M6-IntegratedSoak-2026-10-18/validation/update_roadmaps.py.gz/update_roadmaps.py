from pathlib import Path

root = Path(__file__).resolve().parents[2]
en = root/'Roadmap/en/2D_Roadmap.md'
zh = root/'Roadmap/zh-TW/2D_Roadmap.md'
text = en.read_text(encoding='utf-8')
text = text.replace('have portable/Linux functional evidence. M6 same-host 30 FPS screen is 24/24 (DX12/Vulkan each 12/12); physical minimum-PC acceptance remains open.',
    'have portable/Linux functional evidence. Latest M6 same-host 30 FPS screen is 23/24; integrated\n> short screens are 3/4 and 30-minute soaks 1/2. Physical minimum-PC acceptance remains open.',1)
text = text.replace('Current-PC DX12/Vulkan 30 FPS screen 24/24; minimum-PC gate NOT ACCEPTED',
    'Latest current-PC screen 23/24, integrated 3/4, 30-minute soak 1/2; M6 NOT ACCEPTED',1)
text = text.replace('Hardware/workload\nbudgets are currently **TBD**; object count alone is not a performance claim.',
    'Product minimum hardware/workload\nbudgets remain **TBD**; dated current-host fixture plans below declare their own fixed loads and\nresource limits. Object count alone is not a performance claim.',1)
heading = '## Integrated 10k UI/VFX and physical 30-minute soaks (2026-10-18)'
assert heading not in text
text += '''
## Integrated 10k UI/VFX and physical 30-minute soaks (2026-10-18)

✅ An opt-in benchmark mode and fixed-plan runner preserve the original six-case `Measure` body,
all 10,000 CPU updates/query shapes and the original 30 FPS limits. The integrated native pass adds
256 animated translucent VFX, two Sprite atlases/batches and actual GameplayUi panels/buttons/text
(120 UI quads/commands). Full-pool/immutable-atlas recycling, codec reload and a touched/freed 8 MiB
scoped allocation repeat while mixed/sparse layouts alternate. Real-time simulation, production
art, asynchronous disk IO and physical input are not inferred from these deterministic fixtures.

✅ Both hardware backends complete 1,800 measured seconds after 1,200 warm-up frames, with zero
lost frame/completed GPU samples and balanced teardown. The formal suite retains 210,785 raw
frames and exact source/executable identities. Original workload non-timing outputs match the
preceding screen. Local Development/Shipping builds and 34/34 related tests pass without skips.

Strict performance is **NOT ACCEPTED**: original screens are 23/24 (DX12 11/12, Vulkan 12/12),
integrated short screens 3/4 and soaks 1/2. DX12 soak has 95,701 measured frames, cycle p99/max
28.4662/62.8658 ms. Vulkan has 95,772, p99 27.7955 ms but max **134.9232 ms**, exceeding the
unchanged 66.6667 ms maximum. DX12 original mixed-10k repeat 1 p99 is 39.3942 ms; Vulkan integrated
repeat 2 p95/p99 is 33.5469/49.2560 ms. No failed rows, cold measured frames or spikes are excluded.

Vulkan frame 24,415 has CPU 14.9771 ms, Draw 5.6583 ms and EndFrame **113.6250 ms**, with neither
reload nor resource polling. Matching submission 24,416 has GPU interval **0.448736 ms**, observed
two frames later. This isolates the broad submit/present boundary, not an individual API or OS/driver
cause. Native API/thread-cycle/scheduling tracing is tracked by `nexora-j4q.2.6`; the earlier DX12
72.3556 ms cause remains separately untraced under `nexora-j4q.2.4`.

✅ All six integrated resource screens meet fixed sampled caps/growth limits. Both soaks retain
two native buffer reallocations, 161 balanced scoped allocations/frees and zero rejected textures.
DX12 private-memory first/last-five-minute median growth is 0.3984 MiB; Vulkan is -0.0078 MiB;
local GPU usage median growth is zero for both. Post-frame RSS/commit/WDDM budget usage and the
explicit loading allocation do not establish full allocator accounting or physical VRAM residency.

[Complete plan, results, failed frames and compressed raw evidence](../../Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18/acceptance.md).
[Tool contract](../../Tools/TwoD/README.md#integrated-10k-load-and-sustained-native-validation).
This record supplements the earlier successful 24/24 screen without replacing its historical verdict.
Keep **M6 NOT ACCEPTED; 9/11 (82%), P0 6/8 unchanged**. Product minimum specification and broader
allocator/production/device/clean-host gates remain open. The delivery PR must remain unmerged while
this fixed physical performance gate fails, regardless of portable/hosted CI success.
'''
en.write_text(text,encoding='utf-8')
text = zh.read_text(encoding='utf-8')
text = text.replace('Portable／Linux 功能證據。M6 同機 30 FPS 篩檢為 24/24（DX12／Vulkan 各 12/12），最低規格實體 PC 驗收仍待完成。M7 乾淨 Windows',
    'Portable／Linux 功能證據。M6 最新同機 30 FPS 篩檢為 23/24，整合短測 3/4、30 分鐘長測 1/2；\n> 最低規格實體 PC 驗收仍待完成。M7 乾淨 Windows',1)
text = text.replace('目前 PC DX12／Vulkan 30 FPS 篩檢 24/24；最低 PC gate 為 NOT ACCEPTED',
    '最新同機篩檢 23/24、整合 3/4、30 分鐘長測 1/2；M6 NOT ACCEPTED',1)
text = text.replace('VFX／UI 負載與載入變動量。硬體／負載預算目前為 **TBD**；物件數本身不是效能保證。',
    'VFX／UI 負載與載入變動量。產品最低硬體／負載預算仍為 **TBD**；下方各次同機 fixture 計畫\n另行固定其負載與資源門檻。物件數本身不是效能保證。',1)
heading = '## 整合 10k UI／VFX 與實體 30 分鐘長測（2026-10-18）'
assert heading not in text
text += '''
## 整合 10k UI／VFX 與實體 30 分鐘長測（2026-10-18）

✅ 新增可選 benchmark 模式與固定計畫 runner，保留原六組 `Measure` 本體、全部 10,000 個 CPU
更新／查詢形狀與原 30 FPS 門檻。同一原生 pass 新增 256 個動畫透明 VFX、兩組 Sprite Atlas／
batch，以及實際 GameplayUi 面板／按鈕／文字（120 個 UI 四邊形／command）。一般／稀疏布局
交替時，反覆執行完整物件池／不可變 Atlas 回收、codec 重載及觸頁後釋放的 8 MiB 範圍配置。
此可重現 fixture 不推論即時模擬、正式美術、非同步磁碟 I/O 或實體輸入驗收。

✅ 兩個硬體後端皆在 1,200 幀暖機後完成 1,800 秒測量，沒有遺失幀／已完成 GPU 樣本，正常釋放。
正式流程保留 210,785 個原始幀與精確來源／執行檔身分。原負載的非計時輸出與前次篩檢一致；
本機 Development／Shipping 建置及相關 34/34 測試通過，無略過。

嚴格效能仍為 **NOT ACCEPTED**：原篩檢 23/24（DX12 11/12、Vulkan 12/12）、整合短測 3/4、
長測 1/2。DX12 長測共 95,701 個測量幀，cycle p99／最大值 28.4662／62.8658 ms。Vulkan 共
95,772 幀，p99 27.7955 ms，但最大值 **134.9232 ms** 超出原 66.6667 ms 門檻。DX12 原混合
10k 第一輪 p99 為 39.3942 ms；Vulkan 整合第二輪 p95／p99 為 33.5469／49.2560 ms。
保留全部失敗列、測量區間冷幀與尖峰。

Vulkan 第 24,415 幀 CPU 14.9771 ms、Draw 5.6583 ms、EndFrame **113.6250 ms**，當幀沒有
重載或資源取樣。對應提交 24,416 的 GPU 區間為 **0.448736 ms**，於兩幀後觀測到。此資料縮小
到提交／呈現邊界，尚不能識別個別 API 或 OS／Driver 原因。`nexora-j4q.2.6` 追蹤原生 API／
執行緒週期／排程關聯；歷史 DX12 72.3556 ms 原因仍由 `nexora-j4q.2.4` 獨立追查。

✅ 六組整合資源篩檢皆符合固定取樣峰值／成長門檻。兩次長測皆維持兩次原生 buffer 配置、
161 次平衡的範圍配置／釋放，且沒有拒絕貼圖。DX12 private memory 前後五分鐘中位數成長
0.3984 MiB，Vulkan 為 -0.0078 MiB；兩後端 local GPU usage 中位數成長皆為零。幀後 RSS／
commit／WDDM 預算用量及明確載入配置，不代表全引擎 allocator 統計或實體 VRAM residency。

[完整計畫、結果、失敗幀與壓縮原始證據](../../Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18/acceptance.md)。
[工具契約](../../Tools/TwoD/README.md#integrated-10k-load-and-sustained-native-validation)。
本次補充前一輪成功的 24/24 紀錄，保留該次歷史判定。**M6 NOT ACCEPTED；9/11（82%）、
P0 6/8 不變。** 產品最低規格與完整 allocator／正式負載／裝置／乾淨主機 gate 仍開放。
此固定實機效能 gate 未通過時，交付 PR 維持未合併，Portable／託管 CI 通過也不豁免。
'''
zh.write_text(text,encoding='utf-8')
sections = {
'en': '''
## Integrated 2D soak follow-up (2026-10-18)

The next fixed same-PC suite retains all original 10k workloads and adds UI/VFX plus 30 measured
minutes per native backend. Local related contracts pass 34/34 and all native functional/sample
checks pass, but current physical performance is **NOT ACCEPTED**: original23/24, integrated3/4,
soak1/2. DX12 soak cycle p99/max is 28.4662/62.8658 ms; Vulkan is 27.7955/**134.9232 ms**.

Vulkan frame24,415 spends 113.6250 ms in EndFrame; matching GPU submission24,416 measures
0.448736 ms. No reload/resource poll occurs on that frame. The boundary includes command
finalization, queue submit/present and metric reads; no individual API or OS/driver cause is
proved. No native API, buffer count, VSync policy or engine ABI changes in this follow-up.
[Raw evidence and retained failures](../../Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18/acceptance.md);
`nexora-j4q.2.6` tracks native API/thread-cycle/scheduling correlation. The older24/24 result is
historical evidence, not proof that every later or longer run passes. Full M6 remains open.
''',
'zh-TW': '''
## 整合 2D 長測後續（2026-10-18）

後續固定同機流程保留全部原 10k 負載，新增 UI／VFX 與每原生後端 30 分鐘測量。本機相關
契約 34/34、原生功能／樣本檢查全部通過，但實機效能仍為 **NOT ACCEPTED**：原篩檢
23/24、整合 3/4、長測 1/2。DX12 長測 cycle p99／最大值為 28.4662／62.8658 ms；
Vulkan 為 27.7955／**134.9232 ms**。

Vulkan 第 24,415 幀 EndFrame 花費 113.6250 ms；對應 GPU 提交 24,416 的區間為
0.448736 ms，該幀沒有重載／資源取樣。此邊界包含命令結束、queue submit／present 與
指標讀取，尚未證明個別 API 或 OS／Driver 原因。本次不改原生 API、buffer 數、VSync
政策或引擎 ABI。[原始證據與保留失敗](../../Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18/acceptance.md)；
`nexora-j4q.2.6` 追蹤原生 API／執行緒週期／排程關聯。先前 24/24 為歷史證據，
不代表後續或更長運行必然通過；完整 M6 維持未驗收。
'''}
for language, section in sections.items():
    path=root/f'Roadmap/{language}/Window_Presentation_Roadmap.md'
    text=path.read_text(encoding='utf-8')
    assert section.splitlines()[1] not in text
    path.write_text(text+section,encoding='utf-8')
print('Updated paired TwoD and Window Presentation roadmaps; root README unchanged')
