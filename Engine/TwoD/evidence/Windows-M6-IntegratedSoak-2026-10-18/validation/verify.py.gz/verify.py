import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--index', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
folder = root/'Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18'
def digest(data):
    return hashlib.sha256(data).hexdigest()
for name, item in json.loads((folder/'archives.json').read_text(encoding='utf-8')).items():
    raw = (folder/name).read_bytes()
    assert digest(raw) == item['archived_sha256'], name
    data = gzip.decompress(raw) if item['compressed'] else raw
    assert digest(data) == item['original_sha256'] and len(data) == item['original_size'], name
source = json.loads((folder/'source-manifest.json').read_text(encoding='utf-8'))
for path, item in source['files'].items():
    raw = gzip.decompress((folder/'source'/f'{path}.gz').read_bytes())
    assert digest(raw) == item['sha256'], path
    assert digest((root/path).read_bytes()) == item['sha256'], path
    if args.index:
        staged = subprocess.check_output(['git','show',f':{path}'],cwd=root)
        assert digest(staged.replace(b'\r\n',b'\n')) == item['lf_sha256'], path
plan = json.loads((folder/'plan.json').read_text(encoding='utf-8'))
identity = json.loads((folder/'identity.json').read_text(encoding='utf-8'))
assert plan['source_sha256'] == identity['source_sha256_after']
assert source['executable_sha256'] == plan['executable_sha256'] == identity['executable_sha256_after']
assert digest((root/'build/windows-m6-soak-20261018/candidate-benchmark.exe').read_bytes()) == plan['executable_sha256']
manifest = {path.relative_to(folder).as_posix():dict(bytes=path.stat().st_size,
              sha256=digest(path.read_bytes())) for path in sorted(folder.rglob('*'))
              if path.is_file() and path.name != 'manifest.json'}
if args.index:
    prior = json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    assert prior == manifest
    for name, item in manifest.items():
        relative = (folder/name).relative_to(root).as_posix()
        staged = subprocess.check_output(['git','show',f':{relative}'],cwd=root)
        assert digest(staged) == item['sha256'], name
else:
    (folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Verified',len(manifest),'artifact hashes, all archived raw bytes, source snapshots and frozen EXE',
      'including staged bytes' if args.index else '')
