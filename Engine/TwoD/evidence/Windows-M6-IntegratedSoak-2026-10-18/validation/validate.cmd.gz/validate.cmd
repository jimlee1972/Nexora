@echo off
call "D:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
set "NEXORA_CMAKE=D:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
set "NEXORA_CTEST=D:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\ctest.exe"
"%NEXORA_CMAKE%" --build build/windows-development --config Development --parallel 2
if errorlevel 1 exit /b %errorlevel%
"%NEXORA_CTEST%" --preset windows-development -C Development -R "^twod\.|^gameplay\..*(twod|ui|content)|^window_presentation\." --output-on-failure --output-log build/windows-m6-soak-20261018/ctest.log --output-junit build/windows-m6-soak-20261018/ctest.xml
exit /b %errorlevel%
