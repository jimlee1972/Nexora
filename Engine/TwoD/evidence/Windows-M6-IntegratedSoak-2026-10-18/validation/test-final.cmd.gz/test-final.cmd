@echo off
call "D:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
"D:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\ctest.exe" --preset windows-development -C Development -R "^twod\.|^gameplay\..*(twod|ui|content)|^window_presentation\." --output-on-failure --output-log build/windows-m6-soak-20261018/ctest-final.log --output-junit build/windows-m6-soak-20261018/ctest-final.xml
exit /b %errorlevel%
