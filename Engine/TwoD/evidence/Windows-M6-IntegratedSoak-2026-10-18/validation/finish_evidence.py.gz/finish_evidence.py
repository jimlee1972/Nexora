import gzip
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
root=work.parents[1]
folder=root/'Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18'
mapping=json.loads((folder/'archives.json').read_text(encoding='utf-8'))
for filename in ['documentation-final.log','update_roadmaps.py','finish_evidence.py']:
    data=(work/filename).read_bytes()
    compressed=gzip.compress(data,mtime=0)
    relative=f'validation/{filename}.gz'
    (folder/relative).write_bytes(compressed)
    mapping[relative]=dict(original_name=filename,original_size=len(data),
       original_sha256=hashlib.sha256(data).hexdigest(),
       archived_sha256=hashlib.sha256(compressed).hexdigest(),compressed=True)
(folder/'archives.json').write_text(json.dumps(mapping,indent=2)+'\n',encoding='utf-8')
path=folder/'acceptance.md'
text=path.read_text(encoding='utf-8')
target='- Full local MSVC Development build and Monolithic Shipping benchmark/compiler build: PASS.'
text=text.replace(target,target+'\n- Documentation regression: **16/16**; all six changed Markdown documents/paired roadmaps validate.\n  Touched C++ clang-format checks pass; root README remains concise and unchanged.',1)
path.write_text(text,encoding='utf-8')
print('Final documentation checks and reproduction helpers archived')
