"""Archive only completed measurement data; never rewrite raw bytes."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
formal = work/'formal'
destination = root/'Engine/TwoD/evidence/Windows-M6-IntegratedSoak-2026-10-18'
assert (formal/'results.json').is_file() and (formal/'identity.json').is_file()
destination.mkdir(parents=True, exist_ok=False)
(destination/'.gitattributes').write_text(
    '* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n'
    'ctest-final.log -whitespace\nimplementation.patch -whitespace\n',encoding='ascii')
archives = {}
def sha(data):
    return hashlib.sha256(data).hexdigest()
def transfer(source, relative, compress=False):
    data = source.read_bytes()
    target = destination/relative
    if compress:
        target = Path(str(target)+'.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0) if compress else data)
    archives[target.relative_to(destination).as_posix()] = dict(
        original_name=source.name, original_size=len(data), original_sha256=sha(data),
        archived_sha256=sha(target.read_bytes()), compressed=compress)
for source in sorted(formal.iterdir()):
    if source.is_file():
        transfer(source, source.name, source.name.endswith('-frames.csv'))
for source in sorted((work/'frozen-source').rglob('*')):
    if source.is_file():
        transfer(source, 'source/'+source.relative_to(work/'frozen-source').as_posix(), True)
for name in ['host.json','source-manifest.json','implementation.patch','duration-smoke.log',
             'duration-smoke-oracle-failure.log','duration-smoke.json']:
    transfer(work/name, name)
for backend in ['dx12','vulkan']:
    for suffix in ['.csv','-frames.csv','.stdout','.stderr']:
        name = f'duration-{backend}{suffix}'
        transfer(work/name,'preflight/'+name,suffix=='-frames.csv')
for name in ['validation-final.log','build-shipping-frozen.log','test-final-console.log',
             'documentation-tests.log','validate.cmd','test-final.cmd','freeze.py','archive.py',
             'duration_smoke.py','verify.py']:
    transfer(work/name,'validation/'+name,True)
transfer(work/'ctest-final.log','ctest-final.log')
transfer(root/'build/windows-development/build/windows-m6-soak-20261018/ctest-final.xml',
         'ctest-final.xml')
(destination/'archives.json').write_text(json.dumps(archives,indent=2)+'\n',encoding='utf-8')
print('Archived',len(archives),'exact byte artifacts into',destination)
