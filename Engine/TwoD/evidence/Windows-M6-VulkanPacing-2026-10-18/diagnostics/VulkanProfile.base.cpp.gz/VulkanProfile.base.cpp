#define _CRT_SECURE_NO_WARNINGS
#include "ProfileTrace.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <vulkan/vulkan.h>
namespace ProfileTrace {
using Clock = std::chrono::steady_clock;
Frame current;
std::uint32_t imageCount{}, requested{}, presentMode{};
void Begin() { current = {}; }
Frame Current() { current.images = imageCount; current.requestedImages = requested; current.mode = presentMode; return current; }
double Elapsed(Clock::time_point start) { return std::chrono::duration<double, std::milli>(Clock::now()-start).count(); }
VkResult Wait(VkDevice d, std::uint32_t n, const VkFence* f, VkBool32 all, std::uint64_t timeout) {
  auto start = Clock::now(); auto r = vkWaitForFences(d,n,f,all,timeout); current.fence += Elapsed(start); return r;
}
VkResult Acquire(VkDevice d, VkSwapchainKHR s, std::uint64_t timeout, VkSemaphore sem, VkFence f, std::uint32_t* image) {
  auto start = Clock::now(); auto r = vkAcquireNextImageKHR(d,s,timeout,sem,f,image); current.acquire += Elapsed(start); current.image = *image; return r;
}
VkResult Submit(VkQueue q, std::uint32_t n, const VkSubmitInfo* s, VkFence f) {
  auto start = Clock::now(); auto r = vkQueueSubmit(q,n,s,f); current.submit += Elapsed(start); return r;
}
VkResult Present(VkQueue q, const VkPresentInfoKHR* p) {
  auto start = Clock::now(); auto r = vkQueuePresentKHR(q,p); current.present += Elapsed(start); return r;
}
VkResult Create(VkDevice d, const VkSwapchainCreateInfoKHR* info, const VkAllocationCallbacks* a, VkSwapchainKHR* s) {
  auto copy = *info;
  if (const auto value = std::getenv("NEXORA_TRACE_IMAGES")) copy.minImageCount = static_cast<std::uint32_t>(std::atoi(value));
  requested = copy.minImageCount; presentMode = copy.presentMode;
  return vkCreateSwapchainKHR(d,&copy,a,s);
}
VkResult Images(VkDevice d, VkSwapchainKHR s, std::uint32_t* n, VkImage* images) {
  auto r = vkGetSwapchainImagesKHR(d,s,n,images); imageCount = *n; return r;
}
}
#define vkWaitForFences ProfileTrace::Wait
#define vkAcquireNextImageKHR ProfileTrace::Acquire
#define vkQueueSubmit ProfileTrace::Submit
#define vkQueuePresentKHR ProfileTrace::Present
#define vkCreateSwapchainKHR ProfileTrace::Create
#define vkGetSwapchainImagesKHR ProfileTrace::Images
#include "../../Engine/Presentation/src/VulkanSurface.cpp"
