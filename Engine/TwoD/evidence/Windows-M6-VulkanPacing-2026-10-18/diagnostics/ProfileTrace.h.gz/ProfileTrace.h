#pragma once
#include <cstdint>
namespace ProfileTrace {
struct Frame {
  double fence{}, acquire{}, submit{}, present{};
  std::uint32_t image{}, images{}, requestedImages{}, mode{};
};
void Begin();
Frame Current();
}
