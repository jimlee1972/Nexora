@echo off
call "d:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
"d:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\ctest.exe" --preset windows-development -C Development -R "^twod\.|^gameplay\..*(twod|ui|content)|^window_presentation\." --output-on-failure --output-log build/windows-dx12-tail-20261018/ctest.log --output-junit build/windows-dx12-tail-20261018/ctest.xml
exit /b %errorlevel%

