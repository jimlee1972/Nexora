@echo off
call "d:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
"d:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe" --build build/windows-showcase-shipping --config Shipping --target NexoraTwoDBenchmark NexoraTwoDAssetCompiler --parallel 2
exit /b %errorlevel%


