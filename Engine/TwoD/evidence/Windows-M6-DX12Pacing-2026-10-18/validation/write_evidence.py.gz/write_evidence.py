import csv,datetime,gzip,hashlib,json,pathlib,shutil,subprocess,xml.etree.ElementTree as ET

root=pathlib.Path(__file__).resolve().parents[2]
work=pathlib.Path(__file__).resolve().parent
out=root/'Engine/TwoD/evidence/Windows-M6-DX12Pacing-2026-10-18'
assert (out/'summary.json').is_file(), 'Formal fixed screen must finish first'
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def archive(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    data=source.read_bytes()
    if target.suffix=='.gz':target.write_bytes(gzip.compress(data,mtime=0))
    else:target.write_bytes(data)
    return dict(source=str(source.relative_to(root)),sha256=sha(data),archive=str(target.relative_to(out)),archive_sha256=sha(target.read_bytes()))

(out/'.gitattributes').write_text('* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\nctest.log -whitespace\nimplementation.patch -whitespace\n')
plan=json.loads((out/'plan.json').read_text());summary=json.loads((out/'summary.json').read_text())
assert len(summary)==4 and all(s['correctness_pass'] for s in summary)
assert plan['frames_per_case']==600 and plan['warmup_frames']==4 and plan['repeats']==2
assert plan['frame_budget_ms']==dict(p95=1000/30,p99=1000/30,maximum=2000/30)
baseline=root/plan['baseline_evidence']
equivalence=[]
for run in summary:
    stem=f"{run['backend']}-{run['repeat']}"
    before=list(csv.DictReader((baseline/f'{stem}.csv').open()))
    after=list(csv.DictReader((out/f'{stem}.csv').open()))
    keys=['objects','sparse','overlap','native','frames','warmup_frames','visible','culled','sprite_batches','covered_aabb_ratio','query_hits','gpu_samples','device_name','vendor_id','device_id','driver_version','driver_version_format','backend_requested']
    assert all(k in after[0] for k in keys), 'load-equivalence column missing'
    differences=[dict(row=i,key=k,before=a[k],after=b[k]) for i,(a,b) in enumerate(zip(before,after)) for k in keys if a[k]!=b[k]]
    assert len(before)==len(after)==6 and not differences,(stem,differences)
    equivalence.append(dict(run=stem,rows=6,compared_columns=keys,differences=differences))
save(out/'load-equivalence.json',equivalence)
frame_summaries=[]
stages=['reload_ms','begin_frame_ms','populate_ms','index_ms','query_ms','extract_ms','draw_ms','end_frame_ms']
for run in summary:
    stem=f"{run['backend']}-{run['repeat']}"
    samples=list(csv.DictReader((out/f'{stem}-frames.csv').open()))
    assert len(samples)==6*604
    report=list(csv.DictReader((out/f'{stem}.csv').open()))
    for i,aggregate in enumerate(report):
        case=samples[i*604:(i+1)*604];measured=[r for r in case if r['warmup']=='0']
        assert len(measured)==600 and [int(r['frame']) for r in case]==list(range(604))
        assert all(abs(sum(float(r[k]) for k in stages)-float(r['frame_ms']))<1e-6 for r in case)
        values=sorted(float(r['frame_ms']) for r in measured)
        for key,value in [('frame_p95_ms',values[569]),('frame_p99_ms',values[593]),('frame_max_ms',values[-1])]:
            assert abs(float(aggregate[key])-value)<=max(1e-4,abs(value)*1e-5)
        frame_summaries.append(dict(run=stem,objects=int(aggregate['objects']),sparse=int(aggregate['sparse']),overlap=int(aggregate['overlap']),top=sorted(measured,key=lambda r:float(r['frame_ms']),reverse=True)[:5]))
save(out/'frame-summary.json',frame_summaries)

sources=[]
for relative,expected in plan['source_files_sha256'].items():
    path=pathlib.Path(pathlib.PureWindowsPath(relative).as_posix())
    source=root/path
    assert sha(source.read_bytes())==expected,relative
    sources.append(archive(source,out/'source'/path.with_suffix(path.suffix+'.gz')))
save(out/'source/manifest.json',sources)

diagnostics=[];reloads=[]
for folder in ['baseline-native','scheduling-native','candidate-admission','candidate-two-queued']:
    subprocess.run(['python',str(work/'summarize.py'),str(work/folder)],check=True,stdout=subprocess.DEVNULL)
    for file in sorted((work/folder).iterdir()):
        if file.is_file():diagnostics.append(archive(file,out/'diagnostics'/folder/(file.name+'.gz' if file.suffix=='.trace' else file.name)))
    for trace in sorted((work/folder).glob('*.trace')):
        for line in trace.read_text().splitlines():
            c=line.split(',')
            if c[0]=='TRACE' and c[4]=='304':
                n=list(map(float,c[5:]))
                reloads.append(dict(trial=folder,run=trace.stem,objects=int(c[1]),sparse=int(c[2]),overlap=int(c[3]),total_ms=sum(n[:8]),reload_ms=n[0],acquire_ms=n[1],native_wait_ms=n[16],native_allocation_ms=n[20],stages_ms=n[:8]))
for folder in ['profile-v1','profile-v2','profile-v3-one-queued']:
    for name in ['BenchmarkProfile.cpp','Dx12Profile.cpp','ProfileTrace.h']:
        diagnostics.append(archive(work/folder/name,out/'diagnostics/source'/folder/(name+'.gz')))
for name in ['BenchmarkProfile.cpp','Dx12Profile.cpp','ProfileTrace.h','run_diagnostic.py','summarize.py','prepare_profile.py','enhance_profile.py','prepare_candidate.py']:
    diagnostics.append(archive(work/name,out/'diagnostics/source/final'/(name+'.gz')))
diagnostics.append(archive(work/'trial-one-queued-Dx12Surface.cpp',out/'diagnostics/source/trial-one-queued-Dx12Surface.cpp.gz'))
save(out/'diagnostics/manifest.json',diagnostics)
save(out/'diagnostics/reload-comparison.json',reloads)
save(out/'diagnostics/etw-status.json',dict(status='UNAVAILABLE',xperf_error='0x3ec',wpr_error='0xc5585011',wpr_message='Failed to enable the policy to profile system performance.',recording_active=False,scope='Observed command output; no usable kernel scheduling trace. Thread-cycle counts do not uniquely identify an OS scheduler or driver cause.'))

for name in ['ctest.log','baseline-regression.log']:
    archive(work/name,out/name)
junit=root/'build/windows-development/build/windows-dx12-tail-20261018/ctest.xml'
archive(junit,out/'ctest.xml')
for name in ['trace-development-build.log','trace-product-build.log','two-queued-development.log','two-queued-build.log','product-build.log','development-build.cmd','development-test.cmd','product-build.cmd','ctest-one-queued.log','ctest-one-queued-command.log','profile-build.log','profile-build-retry.log','profile-v2-build.log','candidate-build.log','etw-start.log','run_acceptance.py','write_evidence.py']:
    archive(work/name,out/'validation'/(name+'.gz'))
if (work/'host.json').is_file():archive(work/'host.json',out/'host.json')

code=['Engine/Presentation/src/Dx12Surface.cpp','Tests/WindowPresentation/Dx12SwapchainTests.cpp','Tests/WindowPresentation/CMakeLists.txt','Tools/TwoD/Benchmark.cpp','Tests/TwoD/BenchmarkTraceAcceptance.py','Tests/TwoD/CMakeLists.txt']
patch=subprocess.check_output(['git','diff','HEAD','--',*code],cwd=root)
assert b'Dx12SwapchainTests.cpp' in patch
(out/'implementation.patch').write_bytes(patch)
tests=ET.parse(junit).getroot()
assert len(tests.findall('testcase'))==33 and not tests.findall('.//failure') and not tests.findall('.//skipped')
passed=sum(row['pass_budget'] for run in summary for row in run['rows'])
rows=[]
for run in summary:
    for row in run['rows']:
        case=f"{row['objects']} {'sparse' if row['sparse']=='1' else 'overlap' if row['overlap']=='1' else 'mixed'}"
        rows.append(f"| {run['backend']} {run['repeat']} | {case} | {row['p95_ms']:.4f} | {row['p99_ms']:.4f} | {row['max_ms']:.4f} | {'PASS' if row['pass_budget'] else 'FAIL'} |")
table='\n'.join(rows)
report=f'''# DX12 VSync admission and retained spike investigation — 2026-10-18

The current-PC screen with unchanged workloads/budgets passes **{passed}/24** rows. This is a physical developer-host
screen, not full 2D-M6 acceptance or a product minimum specification.

## Change and retained uncertainty

Shared DX12 VSync waits for DXGI presentation capacity at Acquire, including the first frame.
One swapchain-owned handle bounds queued frames to the existing two/three frame slots; separate
GPU fences still protect allocators, uploads, timestamps and retirement. Resize retains the flags
and handle, zero extent suspends before waiting, failed waits reject acquisition, and drain closes
the handle once. Immediate retains its asynchronous admission. Public headers and C/Zig ABI are
unchanged by this DX12 change. This affects shared engine consumers, not a benchmark-only branch.
Microsoft documents the [waitable handle contract](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_3/nf-dxgi1_3-idxgiswapchain2-getframelatencywaitableobject)
and [queue capacity](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_3/nf-dxgi1_3-idxgiswapchain2-setmaximumframelatency).

The previous [72.3556 ms DX12 sparse failure](../Windows-M6-VulkanPacing-2026-10-18/acceptance.md)
remains retained. Its aggregate CSV cannot identify the same-frame cause, and fixed diagnostic
repeats did not reproduce that event. No scheduler/driver attribution or proof of eliminating its
unique root cause is claimed. Current Windows policy prevents ETW CPU capture; exact error codes
and separate native/stage clocks, QPC values and thread-cycle observations are retained.

Diagnostics do establish queued GPU-fence waits around low-load reloads. A single queued-frame
trial reduced reload waits but regressed 10k mixed/sparse p99, so it was rejected. Both failed
repeats and their source/binary identities remain. The final policy retains CPU/GPU overlap with
queue capacity equal to frame slots. See [same-frame reload comparison](diagnostics/reload-comparison.json)
and complete compressed traces/source snapshots in [the diagnostic manifest](diagnostics/manifest.json).
Diagnostics are separate from the formal benchmark's optional checked-in stage trace below.

## Fixed physical screen

- Same FX-6100, 16 GiB, GTX 960 2 GiB, Windows 10 host; native identity is preserved in every CSV.
- 640x480 windowed VSync; same six cases, including 10,000 mixed and 10,000 sparse objects.
- 600 measured + four warm-up frames; two repeats per backend, ordered DX12/Vulkan/DX12/Vulkan.
- All animation, movement, complete spatial rebuild/query/sweep, extraction/culling/order,
  instanced drawing, full pool recycle and immutable Atlas retirement/reload remain.
- Unchanged predeclared p95/p99 <= 1000/30 ms and maximum <= 2000/30 ms. No failed row is dropped.
- Builds/other Nexora fixtures finish before timing; normal desktop applications remain open.

The benchmark adds optional buffered per-frame clocks; original CPU/render work and aggregate
CSV fields stay intact. Every formal process enables `--frame-trace`, including its extra clocks
inside the original full-frame interval. Per-case samples write after drain, outside that interval.
[Frame summaries](frame-summary.json) retain the same frame's CPU and all eight contiguous stages;
raw CSV has all 604 frames/case, including explicit warm-up flags. Aggregate p95/p99/max are
recomputed from the trace as a consistency check. [Load equivalence](load-equivalence.json)
compares every row's counts, coverage, queries, GPU samples and native identity. The
[advance plan](plan.json), [all process results](summary.json), [binary/CSV hashes](identity.json)
and [source snapshots](source/manifest.json) identify the measured candidate. Process memory
samples are working set/private commit, not total VRAM/allocator accounting or soak evidence.

| Run | Case | p95 ms | p99 ms | Maximum ms | Result |
| --- | --- | ---: | ---: | ---: | --- |
{table}

## Validation and boundaries

The full local MSVC Development build and canonical Monolithic Shipping benchmark/compiler build
pass. Related CTest is **33/33**, zero failures/skips, including actual DX12 VSync/Immediate,
two/three slots, wait failure, resource drain, resize, suspension and handle cleanup. The same
new regression fails the old adapter on missing first-frame admission, with exit 1 as expected.
Existing DX12/Vulkan native PBR and 2D contracts remain in this gate. The portable trace
test verifies all six cases, warm-up/sample identity, same-frame stage partitions, CPU/full
percentile parity, unchanged ordinary CSV schema and rejection of aliased/invalid output.

Exact commands and output are retained in [validation artifacts](validation/product-build.cmd.gz),
[CTest log](ctest.log), [JUnit](ctest.xml) and [the old-adapter counterexample](baseline-regression.log).
The final PR head's full hosted Linux Development configure/build/CTest, Linux Shipping and other
platform jobs are evaluated on [PR #644](https://github.com/jimlee1972/Nexora/pull/644) before merge.
Physical Windows results do not establish Linux/macOS results, and hosted results do not replace
this physical screen. Public source is base `{plan['source']}` plus the retained implementation
patch and exact working-source hashes; no executable or generated build tree is committed.

The original isolated 72.3556 ms cause remains untraced. Product minimum specification,
integrated UI/VFX, allocator/VRAM, long-duration operation and clean-host/device acceptance remain
open. **M6 NOT ACCEPTED; roadmap 9/11 (82%), P0 6/8 unchanged.**
'''
(out/'acceptance.md').write_text(report,encoding='utf-8')
manifest={str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p!=out/'manifest.json'}
save(out/'manifest.json',manifest)
print(f'Wrote {len(manifest)} artifact identities; formal screen {passed}/24; source/load/JUnit verified')
