#pragma once
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <array>
#include <iostream>
#include <chrono>
#include <cstdint>
namespace ProfileTrace {
struct Frame {
 double fence{}, acquire{}, submit{}, present{};
 std::uint32_t image{}, images{}, requestedImages{}, mode{};
 std::array<double,8> wall{};
 std::array<std::uint64_t,8> cycles{};
};
inline std::int64_t Counter() { LARGE_INTEGER v{}; QueryPerformanceCounter(&v); return v.QuadPart; }
inline void ClockIdentity() { LARGE_INTEGER f{}; QueryPerformanceFrequency(&f); FILETIME t{}; GetSystemTimePreciseAsFileTime(&t); const auto q=Counter(); std::cerr << "CLOCK," << q << ',' << f.QuadPart << ',' << ((std::uint64_t(t.dwHighDateTime)<<32)|t.dwLowDateTime) << ',' << GetCurrentProcessId() << '\n'; }
struct DirectScope {
 double& slot; std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
 ~DirectScope() { slot+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(); }
};
inline Frame current;
inline void Begin() { current={}; }
inline Frame Current() { return current; }
inline std::uint64_t Cycles() { ULONG64 v{}; QueryThreadCycleTime(GetCurrentThread(),&v); return v; }
struct Scope {
 unsigned slot; std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
 std::uint64_t cycles=Cycles();
 ~Scope() { current.wall[slot]+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(); current.cycles[slot]+=Cycles()-cycles; }
};
template<class F> decltype(auto) Call(unsigned slot,F f) { Scope s{slot}; return f(); }
}
