import pathlib,shutil
work=pathlib.Path(__file__).resolve().parent
snapshot=work/'profile-v1';snapshot.mkdir(exist_ok=False)
for name in ['Dx12Profile.cpp','BenchmarkProfile.cpp','ProfileTrace.h']:
    shutil.copyfile(work/name,snapshot/name)
shutil.copyfile(work.parent/'windows-showcase-shipping/bin/Shipping/NexoraTwoDDx12Profile.exe',snapshot/'profile.exe')
header=work/'ProfileTrace.h'
s=header.read_text().replace('inline Frame current;','''inline std::int64_t Counter() { LARGE_INTEGER v{}; QueryPerformanceCounter(&v); return v.QuadPart; }
inline void ClockIdentity() { LARGE_INTEGER f{}; QueryPerformanceFrequency(&f); FILETIME t{}; GetSystemTimePreciseAsFileTime(&t); const auto q=Counter(); std::cerr << "CLOCK," << q << ',' << f.QuadPart << ',' << ((std::uint64_t(t.dwHighDateTime)<<32)|t.dwLowDateTime) << ',' << GetCurrentProcessId() << '\\n'; }
struct DirectScope {
 double& slot; std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
 ~DirectScope() { slot+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(); }
};
inline Frame current;''').replace('#include <array>','#include <array>\n#include <iostream>')
header.write_text(s)
path=work/'Dx12Profile.cpp';s=path.read_text()
s=s.replace('  SurfaceStatus Acquire() override {','  SurfaceStatus Acquire() override {\n    ProfileTrace::DirectScope acquireTime{ProfileTrace::current.acquire};')
s=s.replace('    meshResidency_.BeginFrame();','    { ProfileTrace::DirectScope retireTime{ProfileTrace::current.submit};\n    meshResidency_.BeginFrame();').replace('    retiredUiDescriptors_[frame_].clear();','    retiredUiDescriptors_[frame_].clear(); }',1)
path.write_text(s)
path=work/'BenchmarkProfile.cpp';s=path.read_text()
s=s.replace('  const auto loading = Clock::now();','  ProfileTrace::ClockIdentity();\n  const auto loading = Clock::now();')
s=s.replace('std::uint64_t cycles;','std::uint64_t cycles; std::array<std::uint64_t,9> stageCycles; std::array<std::int64_t,9> counters;')
s=s.replace('    const auto beginCycles = ProfileTrace::Cycles();','    const auto beginCycles = ProfileTrace::Cycles();\n    std::array<std::uint64_t,9> stageCycles{}; std::array<std::int64_t,9> counters{}; stageCycles[0]=beginCycles; counters[0]=ProfileTrace::Counter();')
for i,name in enumerate(['beforeAcquire','update','populated','indexed','queried','extractedAt','drawn','end'],1):
    marker=f'    const auto {name} = Clock::now();'
    if name=='drawn':marker='      drawn = Clock::now();'
    assert marker in s,name
    s=s.replace(marker,marker+f'\n    stageCycles[{i}]=ProfileTrace::Cycles(); counters[{i}]=ProfileTrace::Counter();')
s=s.replace('ProfileTrace::Current(), ProfileTrace::Cycles()-beginCycles});','ProfileTrace::Current(), ProfileTrace::Cycles()-beginCycles,stageCycles,counters});')
s=s.replace("<< GetCurrentThreadId() << '\\n';","<< GetCurrentThreadId(); for(auto v:s.stageCycles) std::cerr << ',' << v; for(auto v:s.counters) std::cerr << ',' << v; std::cerr << '\\n';")
path.write_text(s)
