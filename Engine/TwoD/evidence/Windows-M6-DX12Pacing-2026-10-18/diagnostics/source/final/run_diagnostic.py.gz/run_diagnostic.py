import argparse, datetime, hashlib, json, pathlib, subprocess

root=pathlib.Path(__file__).resolve().parents[2]
work=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--repeats',type=int,default=4);args=p.parse_args()
out=work/args.name;out.mkdir(exist_ok=False)
exe=root/'build/windows-showcase-shipping/bin/Shipping/NexoraTwoDDx12Profile.exe'
sources=[root/'Engine/Presentation/src/Dx12Surface.cpp',root/'Tools/TwoD/Benchmark.cpp',work/'BenchmarkProfile.cpp',work/'Dx12Profile.cpp',work/'ProfileTrace.h']
identity=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),scope='DIAGNOSTIC ONLY; fixed repeats, original six mixed workloads, 600 measured + 4 warm-up per case; buffered native API/stage clocks and thread cycle counters',native_slots=['wait','present','execute','signal','allocation','map','reset','set_event'],source_sha256={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources})
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for repeat in range(1,args.repeats+1):
    stem=f'dx12-{repeat}'
    command=[str(exe),'--native','--backend','dx12','--frames','600','--report',str(out/f'{stem}.csv')]
    with (out/f'{stem}.stdout').open('wb') as stdout,(out/f'{stem}.trace').open('wb') as stderr:
        result=subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,timeout=600)
    print(f'{stem}: exit {result.returncode}',flush=True)
    if result.returncode:raise RuntimeError(stem)
