import argparse,pathlib,re,shutil,subprocess
work=pathlib.Path(__file__).resolve().parent;root=work.parents[1]
p=argparse.ArgumentParser();p.add_argument('--snapshot',default='profile-v2');args=p.parse_args()
snapshot=work/args.snapshot;snapshot.mkdir(exist_ok=False)
for name in ['Dx12Profile.cpp','BenchmarkProfile.cpp','ProfileTrace.h']:
    shutil.copyfile(work/name,snapshot/name)
shutil.copyfile(root/'build/windows-showcase-shipping/bin/Shipping/NexoraTwoDDx12Profile.exe',snapshot/'profile.exe')
source=(root/'Engine/Presentation/src/Dx12Surface.cpp').read_text()
patterns={r'WaitForSingleObject':0,r'swapchain_->Present':1,r'queue_->ExecuteCommandLists':2,r'queue_->Signal':3,r'device_->CreateCommittedResource':4,r'(?:ActiveSceneUpload\(\)\.|allocation\.)?\w+->Map':5,r'(?:allocators_\[frame_\]|commands_)->Reset':6,r'fence_->SetEventOnCompletion':7}
matches=[]
for pattern,slot in patterns.items():
    for m in re.finditer(r'\b'+pattern+r'\s*\(',source):
        depth=1;end=m.end()
        while depth:depth+=(source[end]=='(')-(source[end]==')');end+=1
        matches.append((m.start(),end,slot))
for start,end,slot in sorted(matches,reverse=True):
    source=source[:start]+f'ProfileTrace::Call({slot}, [&]() {{ return '+source[start:end]+'; })'+source[end:]
source=source.replace('  SurfaceStatus Acquire() override {','  SurfaceStatus Acquire() override {\n    ProfileTrace::DirectScope acquireTime{ProfileTrace::current.acquire};').replace('    meshResidency_.BeginFrame();','    { ProfileTrace::DirectScope retireTime{ProfileTrace::current.submit};\n    meshResidency_.BeginFrame();').replace('    retiredUiDescriptors_[frame_].clear();','    retiredUiDescriptors_[frame_].clear(); }',1)
(work/'Dx12Profile.cpp').write_text('#include "ProfileTrace.h"\n'+source)
(work/'Dx12Baseline.cpp').write_bytes(subprocess.check_output(['git','show','6d113e80:Engine/Presentation/src/Dx12Surface.cpp'],cwd=root))
test=(root/'Tests/WindowPresentation/Dx12SwapchainTests.cpp').read_text().replace('../../Engine/Presentation/src/Dx12Surface.cpp','Dx12Baseline.cpp')
(work/'BaselineRegression.cpp').write_text(test)
cmake=root/'Tools/TwoD/CMakeLists.txt';(work/'TwoDCMake.candidate.original').write_bytes(cmake.read_bytes())
addition='''
# Local diagnostic only; restored before delivery.
add_executable(NexoraTwoDDx12Profile
 "${CMAKE_SOURCE_DIR}/build/windows-dx12-tail-20261018/BenchmarkProfile.cpp"
 "${CMAKE_SOURCE_DIR}/build/windows-dx12-tail-20261018/Dx12Profile.cpp")
target_include_directories(NexoraTwoDDx12Profile PRIVATE "${CMAKE_SOURCE_DIR}/Engine/Presentation/src")
target_link_libraries(NexoraTwoDDx12Profile PRIVATE Nexora::TwoD d3d12 dxgi d3dcompiler)
nexora_apply_defaults(NexoraTwoDDx12Profile)
add_executable(NexoraDx12BaselineRegression "${CMAKE_SOURCE_DIR}/build/windows-dx12-tail-20261018/BaselineRegression.cpp")
target_include_directories(NexoraDx12BaselineRegression PRIVATE "${CMAKE_SOURCE_DIR}/Engine/Presentation/src" "${CMAKE_SOURCE_DIR}/Engine/Presentation/include")
target_compile_definitions(NexoraDx12BaselineRegression PRIVATE NEXORA_PRESENTATION_STATIC=1)
target_link_libraries(NexoraDx12BaselineRegression PRIVATE Nexora::RHI Nexora::Window d3d12 dxgi d3dcompiler)
nexora_apply_defaults(NexoraDx12BaselineRegression)
'''
cmake.write_bytes(cmake.read_bytes()+addition.encode())
