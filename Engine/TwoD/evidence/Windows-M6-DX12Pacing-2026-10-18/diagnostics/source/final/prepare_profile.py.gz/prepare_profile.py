import pathlib, re

root = pathlib.Path(__file__).resolve().parents[2]
work = pathlib.Path(__file__).resolve().parent
previous = root / 'build/windows-vulkan-tail-20261018'
cmake = root / 'Tools/TwoD/CMakeLists.txt'
(work / 'TwoDCMake.original').write_bytes(cmake.read_bytes())

header = '''#pragma once
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <array>
#include <chrono>
#include <cstdint>
namespace ProfileTrace {
struct Frame {
 double fence{}, acquire{}, submit{}, present{};
 std::uint32_t image{}, images{}, requestedImages{}, mode{};
 std::array<double,8> wall{};
 std::array<std::uint64_t,8> cycles{};
};
inline Frame current;
inline void Begin() { current={}; }
inline Frame Current() { return current; }
inline std::uint64_t Cycles() { ULONG64 v{}; QueryThreadCycleTime(GetCurrentThread(),&v); return v; }
struct Scope {
 unsigned slot; std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
 std::uint64_t cycles=Cycles();
 ~Scope() { current.wall[slot]+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(); current.cycles[slot]+=Cycles()-cycles; }
};
template<class F> decltype(auto) Call(unsigned slot,F f) { Scope s{slot}; return f(); }
}
'''
(work / 'ProfileTrace.h').write_text(header)
benchmark = (previous / 'BenchmarkProfile.cpp').read_text()
start = benchmark.index('  if (std::getenv("NEXORA_TRACE_RENDER_ONLY"))')
end = benchmark.index('  std::vector<double> cpu, gpu, whole;', start)
benchmark = benchmark[:start] + benchmark[end:]
benchmark = benchmark.replace('ProfileTrace::Frame native;','ProfileTrace::Frame native; std::uint64_t cycles;')
benchmark = benchmark.replace('    const auto begin = Clock::now();','    const auto begin = Clock::now();\n    const auto beginCycles = ProfileTrace::Cycles();')
benchmark = benchmark.replace('ProfileTrace::Current()});','ProfileTrace::Current(), ProfileTrace::Cycles()-beginCycles});')
old = "<< n.mode << '\\n';"
new = "<< n.mode; for(auto t:n.wall) std::cerr << ',' << t; for(auto t:n.cycles) std::cerr << ',' << t; std::cerr << ',' << s.cycles << ',' << GetCurrentThreadId() << '\\n';"
assert old in benchmark
benchmark = benchmark.replace(old,new)
(work / 'BenchmarkProfile.cpp').write_text(benchmark)

source = (root / 'Engine/Presentation/src/Dx12Surface.cpp').read_text()
# Time the original expressions, including native API waits, without changing arguments/results.
patterns = {
 r'WaitForSingleObject': 0,
 r'swapchain_->Present': 1,
 r'queue_->ExecuteCommandLists': 2,
 r'queue_->Signal': 3,
 r'device_->CreateCommittedResource': 4,
 r'\w+->Map': 5,
 r'(?:allocators_\[frame_\]|commands_)->Reset': 6,
 r'fence_->SetEventOnCompletion': 7,
}
matches=[]
for pattern,slot in patterns.items():
    for m in re.finditer(r'\b'+pattern+r'\s*\(',source):
        depth=1; end=m.end()
        while depth:
            depth += (source[end]=='(')-(source[end]==')'); end+=1
        matches.append((m.start(),end,slot))
for start,end,slot in sorted(matches,reverse=True):
    source=source[:start]+f'ProfileTrace::Call({slot}, [&]() {{ return '+source[start:end]+'; })'+source[end:]
source='#include "ProfileTrace.h"\n'+source
(work / 'Dx12Profile.cpp').write_text(source)
addition='''
# Local diagnostic only; restored before delivery.
add_executable(NexoraTwoDDx12Profile
 "${CMAKE_SOURCE_DIR}/build/windows-dx12-tail-20261018/BenchmarkProfile.cpp"
 "${CMAKE_SOURCE_DIR}/build/windows-dx12-tail-20261018/Dx12Profile.cpp")
target_include_directories(NexoraTwoDDx12Profile PRIVATE "${CMAKE_SOURCE_DIR}/Engine/Presentation/src")
target_link_libraries(NexoraTwoDDx12Profile PRIVATE Nexora::TwoD d3d12 dxgi d3dcompiler)
nexora_apply_defaults(NexoraTwoDDx12Profile)
'''
cmake.write_bytes(cmake.read_bytes()+addition.encode())
