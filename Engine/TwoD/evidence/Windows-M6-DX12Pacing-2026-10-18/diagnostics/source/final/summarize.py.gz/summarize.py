import argparse,csv,json,pathlib
p=argparse.ArgumentParser();p.add_argument('folder');args=p.parse_args()
folder=pathlib.Path(args.folder)
stage_names=['reload','acquire','populate','index','query','extract','draw','end']
native_names=['wait','present','execute','signal','allocation','map','reset','set_event']
result={}
for path in sorted(folder.glob('*.trace')):
    cases={}
    for line in path.read_text().splitlines():
        if not line.startswith('TRACE,'):continue
        cells=line.split(',')
        if len(cells) not in (39,57) or not all(cells):continue
        key=','.join(cells[1:4]);n=list(map(float,cells[5:]));frame=int(cells[4])
        if frame<4:continue
        sample=dict(frame=frame,total_ms=sum(n[:8]),stages=dict(zip(stage_names,n[:8])),native_ms=dict(zip(native_names,n[16:24])),native_cycles=dict(zip(native_names,n[24:32])),thread_cycles=n[32])
        if len(cells)==57:
            sample['native_acquire_ms']=n[9];sample['retirement_ms']=n[10]
            sample['stage_cycles']={name:n[35+i]-n[34+i] for i,name in enumerate(stage_names)}
            sample['qpc']=n[43:52]
        cases.setdefault(key,[]).append(sample)
    result[path.name]={}
    for key,samples in cases.items():
        values=sorted(s['total_ms'] for s in samples)
        if len(values)!=600:continue
        result[path.name][key]=dict(frames=len(samples),p95_ms=values[569],p99_ms=values[593],max_ms=values[-1],over_limit=[s for s in samples if s['total_ms']>2000/30],top=sorted(samples,key=lambda s:s['total_ms'],reverse=True)[:5])
(folder/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for file,cases in result.items():
    for case,data in cases.items():
        sample=data['top'][0]
        print(file,case,'p99',round(data['p99_ms'],3),'max',round(data['max_ms'],3),'frame',sample['frame'],'stages',','.join(f'{k}={v:.2f}' for k,v in sample['stages'].items()),'native',','.join(f'{k}={v:.2f}' for k,v in sample['native_ms'].items()))
